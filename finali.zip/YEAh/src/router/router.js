import loginView from "@/views/loginView";
import homeView from "@/views/homeView";
import { isAuthenticated } from "@/utils";
import NotFoundView from "@/views/notFound";

const routes = {
  "/": loginView,
  "/home": homeView,
};

export const navigateTo = (path) => {
  history.pushState({}, "", path);
  router();
};

export const router = () => {
  
  

  const path = window.location.pathname;
  
  if (path === "/home" && !isAuthenticated()) {
        navigateTo("/");
        return;
    }

  const view = routes[path] || NotFoundView;
  document.getElementById("app").innerHTML = view();
};
    

window.addEventListener("popstate", router);
